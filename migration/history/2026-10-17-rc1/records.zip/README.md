# 持续对齐记录

2026-10-16：下一目标 `dsh-v0.1.5-rc.3 / a4c74a91` 已开始候选评估，活动基线仍为下述rc.1。实际rc.1→rc.3差分、297-manifest候选矩阵、Session v3/Prompt/文件服务闭包与Desktop交接见 [实施路径评估](../docs/research/2026-10-16-rc3-baseline-implementation-assessment.md) 和 [候选区](candidates/rc3/README.md)。Desktop遵循指定Standard/AIO调研；本轮未切pin、未实施业务迁移或提升验收状态。

2026-10-15 活动基线 **dsh-v0.1.2-rc.1 / a66e4702047846cdaa10c66c9d3df3951f5ea70d** 已完成约定范围签收。干净代码 `d5f74c2da78f4d81b5fe3d9f1251fed31c03174e` 的单次完整门禁通过：Python 10,738通过/6项既有环境跳过、21组 Source 配置、82个配对驱动及实际解压/现代和108浏览器三预设 fresh/cold 通过。新任务 `MIG-RC1-ALIGNMENT-001` 集成86份当前有限合同；旧任务和 alpha 原始证据保留历史身份，九项既有缺陷判据重新实测。精确 ZIP 与原始观察封存在 [资格载体](evidence/artifacts/RC1-QUALIFICATION-20261015-D5F74C2D.zip)，见 [正式回执](evidence/RUN-RC1-QUALIFICATION-20261015-D5F74C2D.json)、[本轮记录](../docs/research/2026-10-15-rc1-baseline-migration-progress.md) 和 [能力矩阵](rc1-capabilities.json)。`accepted_upstream` 仍为 null：这不是全部274个 manifest、任意插件 ABI、真实云 provider 或 Win7 真机的完整认证。本轮不发布 Release；后续记录提交不重标合格代码。以下是各阶段历史，较早状态不代表当前 pin。

2026-10-14 后续 Session 批次：显式 rc.1 logical header、独立 inherited cut/ownEvents/isOwnSeq、私有 version-0 JSONL 翻译、preparation/projection 消费和 ignorable 保留已定向实现；最终 136 Python 用例通过，实际 Source/native 14 类匹配，审批消费者按原 Node 身份复验 122 项通过。默认 alpha 准入与 canonical decode、完整 query/Remote/SDK/子代理闭包仍待协调切换；不是 rc.1 或发行签收。见 [继承切分推进记录](../docs/research/2026-10-14-rc1-session-lineage-progress.md)。

2026-10-14 用户授权 rc.1 推进：候选目标固定 `a66e4702047846cdaa10c66c9d3df3951f5ea70d`，正式差分观察、274-manifest 候选清单、路径引用提供端/Remote/原版 Chromium108 首次启动与冷恢复、轮次摘要/raw-view gate、索引读取和提示词顺序接口已完成首批定向验证。独立 rc.1 原版官方构建和有限 Source/native 配对保留；当前 alpha 台账结构检查通过，既有 86 项及历史验收未提升为 rc.1。Session 逻辑 lineage/持久化/消费者闭合后整体切换 pin、台账和原样前端，稳定后执行一次完整资格。见 [推进记录](../docs/research/2026-10-14-rc1-bootstrap-progress.md) 和 [候选行动区](candidates/rc1/README.md)。

**2026-10-11 v0.1.1已发布：** 干净`919efa919aea9dccdfd87f9ddbc9a44aa642999a`的[完整CI 38117543454](https://github.com/czh869452912/deepseek-harness-win7/actions/runs/38117543454)单次统一门禁通过，Python10564通过/2跳过、22组固定Source、83组配对及实际解压Portable/现代Edge/固定Chromium108旅程均通过。公开[Release](https://github.com/czh869452912/deepseek-harness-win7/releases/tag/v0.1.1)的实际下载ZIP SHA-256 `697dc0368f810c135b28e8d3dd94c529fea7c9f35de90cb1f42bdc1e1e6b56c9`与完整回执及CI验收资产相同；标签保留在该合格候选，不把后续记录提交算作产品。发布附带SHA256SUMS.txt与原始release-verification.json，正式资格见RUN-RELEASE-V011-CI-20261011-919EFA91。已核验清理本次4个传输重复件/959380004字节，此前亦核验清理三份重建夹具副本14541924字节和四份已结束回执控制1532字节；正式原始观察/此前工作流阻断保留。原16有限闭环/九项Source判据不变，Win7真机继续延期，浏览器realm等后续审查不自动认证。以下为此前阶段历史。

2026-10-11 第十轮：87b57409 的 CI 38112306333 完整Python10552通过/2跳过/0失败、22Source执行成功，后续cordis-runner Source快照拒绝。输入哈希与所有业务数据相同，唯一差异是六处同一apply-error栈中原末尾Vitest帧被Node runNextTicks/processTimers调度布局替代，所有Source文件/行/列相同；15实际Source/native旅程均符合原classify判据。原完整观察封存于 RUN-RELEASE-CI-ATTEMPT10-20261011-87B57409，656449880字节自有传输副本清理。原Source快照字节未改，仅加入这份实际捕获的完整精确栈布局：六处必须一致，Source帧/业务/输入/其他旅程/未知栈仍严格拒绝，无通用栈过滤，九上游判据不改。实际新鲜15旅程配对及37个直接生命周期/Remote/独立进程/双布局正例和漂移拒绝通过，见 RUN-RELEASE-CORDIS-STACK-TARGETED-20261011-87B57409，自有测试工作区已清理。下一稳定候选重新取得完整同包资格；原失败不补签，v0.1.1仍草稿、Win7真机延期。以下为历史。

2026-10-11 修正后冷 CI：7ead3838 的 CI 38111619074 三次独立24场景原版/本机配对全部 matched，三项静默场景两侧均确实送达一次原请求，完整请求/错误/流观察没有差异。原始载体与冻结调用见 RUN-RELEASE-ERROR-FIX-CI-20261011-7EAD3838，传输重复件已清理，原失败保持。已知修正及88项本机/实际冷配对定向完成，下一稳定候选执行新鲜完整同包门禁；v0.1.1未发布，旧任务及Win7延期不变。以下为历史。

2026-10-11 实际冷差异及夹具修正：ae40ec49 的 CI 38110658588 三次原配对均严格失败，具体仅 idle/idle-whole-float（3次）及 idle-fraction（2次）请求差异：Source 已收到原完整请求，Python 在150/150.5ms静默超时前未送达；两侧完整error/accepted/chunks及其余行相同。原始输入/两侧捕获及三次失败独立封存于 RUN-RELEASE-ERROR-CI-20261011-AE40EC49，174464字节下载重复件清理。三个配对输入现显式2500/2500.0/2500.5ms，继续验证整数/浮点/分数完整文本及确实送达的一次请求；仅自有服务释放看门狗上限10秒，finally立即释放。生产默认及80/150ms拒绝不改、严格字段不忽略，修复后冷定向与新完整资格仍待取得。原第八/九轮缺失的原始差异行不回填原因，v0.1.1仍未发布。下文为历史。

2026-10-11 第九轮首错：b4fb0058 的 CI 38109212750 在首个共享发行夹具失败处及时退出，3564 通过/1 失败/1 跳过，完整 XML/原工作区/summary 均保留。deepseek_error_oracle 严格拒绝完整 HTTP 观察，但旧 TemporaryDirectory 已删除两侧捕获，具体差异行及原因不能推断；与第八轮是否同因亦不确定。原始材料封存于 RUN-RELEASE-CI-ATTEMPT9-20261011-B4FB0058，自有两个传输副本 7857690 字节清理。错误观察器失败回执现保留完整两侧捕获和原 SHA，严格拒绝不变；独立冷 CI deepseek-error 范围执行三次新鲜原始观察并逐次保留全部输出，任一次失败均报告失败，不拼接签收或重跑完整门禁。v0.1.1 未发布、Win7 真机延期。下文为历史。

2026-10-11 新候选准备：冷 CI 38108105071 的首个真实共享发行夹具 1 项通过（209.75 秒），未重现第八轮确切异常，不能据此补签原运行。完整发行 pytest 现在首个失败时退出并保留 XML/失败工作区，避免重复失败耗尽工作流时限；成功路径仍须执行全部收集与后续严格门禁。实际进程成功/失败、工作区/消费者及超时回收 21 项定向通过，原失败控制封存，自有生成夹具已清理；冷 CI 下载重复件 64069 字节清理。见 RUN-RELEASE-FIXTURE-CI-20261011-8A02A6DB 与 RUN-RELEASE-FAILFIRST-TARGETED-20261011-8A02A6DB。下一稳定候选执行新鲜同包完整发行资格；v0.1.1 尚未发布，Win7 真机延期，旧任务及九判据不变。下文为历史。

2026-10-11 第八轮：d7b3e2f4原180分钟总时限取消，Python约39%共享发行夹具连续失败，完整XML/summary/外部工作区未保留，具体异常/数量不推断。原部分输出/输入/映射及缺口见RUN-RELEASE-CI-ATTEMPT8-20261011-D7B3E2F4；下载副本1631862字节清理。新增首个共享夹具单例冷CI诊断，先定位/定向再计划完整新资格；当前仍草稿，旧任务/判据/延期Win7不变。

2026-10-11 第七轮：149c8f04完整Python10545通过/2跳过，22Source成功，DeepSeek静默请求在150ms内未送达导致严格配对拒绝；原失败见RUN-RELEASE-CI-ATTEMPT7-20261011-149C8F04，654MB传输重复件清理。显式两侧2500ms静默输入及真实socket/适配器超时文本竞争修复后，配对、76完整捕获、150相关消费者通过，调用方取消/短deadline保持。见RUN-RELEASE-IDLE-TARGETED-20261011-149C8F04；自有49文件已清理，旧任务/九判据/延期Win7不推广，新同包完整资格待取得。

2026-10-11 第六轮：be11c724统一验证器0/passed/publishable，10541通过/2跳过、22Source/83配对和实际解压/现代及108通过；后续CI回执解析空键失败，未上传原ZIP，发布阻断。完整资格及工作流失败分开保留于RUN-RELEASE-CI-ATTEMPT6-20261011-BE11C724，751MB自有传输副本已清理。Hashtable回执读取实际5项正/拒绝通过，新同包资格仍待取得；旧任务/判据/延期Win7不变。

2026-10-11 修复后冷CI：75d7ae9d实际五个Windows模块25通过/0失败/0跳过，原八项受限初始化失败与缺用户默认ACL回归覆盖，隔离/只读/私有TEMP/Job/PTY/实际工具边界通过。原始载体和下载绑定见RUN-RELEASE-WINDOWS-CI-20261011-75D7AE9D，传输重复件已清理。下一稳定候选执行完整发行门禁，当前仍为草稿；不拼接局部结果或推广旧任务证据，Win7真机继续延期。

2026-10-11 默认对象ACL：实际CI固定原LUA/写限制，八组缺当前用户首次访问条目均失败，补当前用户条目八组均0；提供者已修复且保留原restricting SID集合。原代码本机回归同3221225794，修复后25相关项及外部写入/只读降级边界通过，原失败和实际诊断封存于RUN-RELEASE-DEFAULT-DACL-20261011-AF2519F9。修复后冷CI与单次完整发行仍待取得，未发布v0.1.1或改变旧16项签收/九项判据。

2026-10-11 启动专项：018f3389的64组实际CI对照中，原LUA/写能力SID配置32组子进程均失败，去LUA对照32组0；仅诊断程序和上传成功，不是生产签收。默认DACL/当前用户首次访问检查继续定向定位，不移除生产LUA或改旧上游判据。正式观察见RUN-RELEASE-STARTUP-CI-20261011-018F3389，v0.1.1仍草稿。

2026-10-11 冷CI定向：d5c0c355实际894项/886通过/8失败，Source冷安装/Host构建/原前端恢复通过；真实受限管道启动仍未解决，原旗标直接启动0不能代替实际runner验收。原始失败封存于RUN-RELEASE-COLD-ENV-20261011-D5C0C355，29MB重复下载已核验清理。继续仅启动诊断，不重跑完整门禁或发布，原16有限闭环不改。见[发行接续](../docs/research/2026-10-11-v0.1.1-release-progress.md)。

2026-10-11 第五轮发行：7d3485b8完整CI仍失败，完整XML10539/8767通过/1770失败或error/2跳过；诊断打包/上传成功，原始载体与绑定正式封存。冷环境原版依赖/构建记录准备、时区/目录碰撞/自有pytest链接控制已调整；受限子进程初始化待实际CI环境定向诊断，不能宣称新发行通过。538MB自有传输副本已核验清理，原载体保留。v0.1.1草稿、原16有限闭环/86历史integrated与延期Win7保持，见[发行接续](../docs/research/2026-10-11-v0.1.1-release-progress.md)。

2026-10-11 发行CI第二阶段：be739d74完整pytest仍退出1，首次直出具体链接/realm/NUL设备失败；10534/1889/2聚合计数保留，打包.exe身份拒绝导致完整XML缺口不隐瞒。已修复CI输入落盘/早期guarded检查、显式中国快照realm及普通文件名，真实固定Node两realm/Git/Agent68项与最终诊断10项通过；生产判据/旧签收不改。原失败/定向/清理封存，自有副本续清约2MB。Release仍为草稿，新的单次完整签收待取得，见[发行接续](../docs/research/2026-10-11-v0.1.1-release-progress.md)。

2026-10-11 v0.1.1 发行准备：用户指定版本并授权发布，Release 尚为草稿。e98a604d 的完整pytest退出1，诊断上传又因1388578文件/Node内存耗尽失败，最终XML和具体失败未取得；原失败及证据缺口正式封存。CI改为不跟随fixture链接的单一诊断ZIP，8项定向通过，新完整结果待取得。原16有限任务闭环/86 integrated历史事实不改写，旧任务输入资格按实际新版本变化显示，不把原f90签收重标为新发行。见[接续记录](../docs/research/2026-10-11-v0.1.1-release-progress.md)。

2026-10-10 当前闭环：用户明确批准Web有限顺序v2，剩余五项增量签收物理退出0；HANDOFF后续16项原记录有限范围全部闭环，86 integrated/0 review。此前81项任务字节未变，所有原验收及finding文本/SHA保留；仅披露四目录完整行排列和四独立mux流全局交错，其余严格值/顺序及九项既有上游判据不变。原失败120/1/1/1仍为失败，产品认证候选仍为原f90ded26及精确ZIP。批准/前后快照/操作正式封存，再删除2准备副本13302237字节。兼容性未归因诊断与延期Win7另查，见[最终记录](../docs/research/2026-10-10-clean-f90-handoff-review-progress.md)。以下81/5及待批准叙述是前阶段记录。

2026-10-10 f90ded26：单次完整发行物理退出0，Python10520通过/6既有skip、22固定Source、83配对、实际解压现代/108通过；16701冻结输入及精确61232e80 ZIP退出后不变。完整与父原始观察正式封存，16项逐条审查完成；用户释放空间后9子项+ACP+JS共11项已独立签收，65有限合同复验同步入账，当前81 integrated/5 review。应用物理退出0，migration check和五项原条款/发现/依赖预检通过，五相关父项仍待独立Web顺序v2批准。此前ENOSPC拒绝及回退保留，原失败120/1/1/1不重标；旧全16应用脚本不可直接重跑。原始与准备数据仅保留正式绑定副本，本轮另清理37文件107793918字节；后续台账/文档不触发新的全套或Portable。清理、接续入口与未归因兼容诊断详见[当前记录](../docs/research/2026-10-10-clean-f90-handoff-review-progress.md)。

2026-10-10 持久欢迎状态接续：dbc3876e完整Python10498通过、22组Source与83配对通过，实际解压/现代浏览器通过；108重复等待同Host已确认欢迎弹窗导致拒绝。16694输入及精确ZIP未变，失败工作区保留。欢迎状态观察器改为显式首次/已确认输入，76状态控制及25实际发行消费者控制通过；同包108和完整父范围须新资格。真实模型/effort冷恢复与两个工具close研究补齐观察，993完成审计清理13.97GB、研究副本另清理813MB，四负例审计及保护历史保留。四策略批准与Web顺序待决定分开，16项不自动提升，见[接续记录](../docs/research/2026-10-10-persisted-browser-notice-progress.md)。

2026-10-10 外部工作区消费者接续：干净b732完整Python10474通过/1失败/20 setup error/6既有skip，4162.76秒；16689输入与精确ZIP不变，后续Source/83配对/解压未执行。嵌套清理夹具缺映射且预期退出码掩盖第二个意外失败，成功的搜索进程因旧root.parent目录假设被拒绝；原始观察独立封存。修正实际归属/逐子XML和调用方精确工作区绑定，新增邻近目录篡改拒绝，真实外部门禁181项通过。当前同ZIP自有Python五预设/13步探针通过，包内字节不变，副本约248MB已核验清理；不是新完整签收。992完成审计清理13.951GB，四负例未完成审计保留，定向另清理约95MB。四策略批准边界、Web顺序待答复、16开放项和延期Win7不自动改变，详见[接续记录](../docs/research/2026-10-10-external-workspace-consumer-progress.md)。

2026-10-10 回归执行目录接续：干净fd2完整Python10488通过/1失败/6既有skip，4114.15秒；原生ReplaceFileW1175拒绝后续发行。16683输入/精确ZIP未变，原失败目标/XML/日志独立封存。发行执行目录改为仓库外系统临时短路径，逐项清理与原子保留的拥有映射同步适配，生产替换语义不改。129控制、实际83通过/4既有平台skip、固定Node最终98回执消费者分别通过，不累加。998审计删除13.957GB，定向另删除前检副本与约218MB合成回执。四策略批准边界保持，Web順序待答复，16项不凭局部结果签收，见[接续记录](../docs/research/2026-10-10-external-regression-workspace-progress.md)。

2026-10-10 Runtime/Scope/保留接续：干净fff0完整Python10482通过/6既有skip，4306.10秒，22组Source与83配对契约通过；实际解压首探针缺Tools的systemPrompt依赖而拒绝，后续解压/浏览器未执行，16项不晋升。16674冻结输入/精确ZIP未变，完整拒绝独立封存；旧验证器删除失败工作区的证据缺口如实披露。探针依赖及显式Agent-owned导出修正后历史同包自有Python旅程通过，真实技能Remote作用域修正通过17消费者；22导出及32失败保留/工作区消费者分别通过。四策略11项token差异有限批准，Web顺序提案待答复。998审计清理13.957GB，另15561文件/248MB默认UI隔离拒绝的原样副本已清理，正式/失败材料保留。见[接续记录](../docs/research/2026-10-10-runtime-scope-retention-progress.md)。

2026-10-09 CSS/压缩/creative接续：干净d02完整Python10421通过/1失败/6既有skip，4068.60秒，旧搜索断言拒绝后续发行，16588输入/精确ZIP不变并封存。修复压缩UUID、creative默认组合/本机锚点及9组vendor身份/许可，推广原版bundle外的Host CSS适配；产品108/现代四fresh/cold严格旅程、15项profile及145项SDK/Web消费者通过。四扩展Tools组合仍保留11个token差异，既有判据未扩大；16项不自动签收。995审计清理约13.89GB及6份解压副本约1.48GB，正式/失败证据保留。见`docs/research/2026-10-09-css-compaction-creative-progress.md`。

2026-10-09 工具/计划/原生搜索接续：干净4a完整Python10341通过/6既有skip、22组Source通过，独立Cordis观察器root导入顺序导致配对阶段拒绝；原包/16573输入/完整XML与989清理审计独立保留，16项不晋升。修复实际Tools抛出值、取消原因与领域HarnessError身份，加入原版计划审批/冷恢复门禁；官方校验和固定rg14及许可证同时供源码/Portable使用，并加入包内空PATH真实搜索与114项导入验证。40/546/112消费者、37完整正例与最终45搜索门禁分别通过，有限修复168成员归档；Source自身20次grep产生两种顺序，原始差异未排序。V7清理约13.79GB，最后定向工作区另1.27GB，相同暂存ZIP82.8MB也已核验删除。新的冻结发行/完整wire/父范围与延期Win7仍待验收，见[本轮记录](../docs/research/2026-10-09-tools-plan-ripgrep-progress.md)。

当前开发验证遵循 `AGENTS.md` 第5节和 [验证指南](../docs/testing.md)：默认定向，稳定关联批次或架构改造准备统一签收、Portable发行候选冻结或用户明确要求时才规划完整门禁。一次门禁失败后集中修复并复验相关控制，不在每项修复/提交/合并/push后自动重跑全套。局部完成与正式acceptance分开，缺失完整证据的任务不晋升；下文历史“下一次全套待执行”等不构成新运行指令。当前CI运行范围尚未调整。

2026-10-08 最新按用户要求改为已有用时审查和定向收尾，不再重复完整集合。第四次2112a470收集10095项，3600秒/约99%中断，无完整XML；SDK失败标记和真实会话保留，不推断最终计数或唯一原因。已修复SDK通知重置期限/遗漏旧帧、工具完成与即时RPC共用10秒等待、SDK观察器及JSONL实际长路径访问，并即时保留失败栈。27项SDK/等待/工作区、100项JSONL/SDK、28项最终边界和4项最终Source配对分别通过，重叠不累计；慢浏览器/SQLite三项通过，用时稳定。发行全套总预算改为可选 `--regression-timeout SECONDS`，单项期限保持。本轮不签收完整发行或提升任务，83026446/65及16开放范围不变；第四次拒绝与有限修复独立归档，见 `docs/research/2026-10-08-full-validation-performance-progress.md`。下面此前“待第四次/不扩大预算”等记述仅保留当时历史，不覆盖本次用户决定。

2026-10-08 第三次干净c53fff6d正常全套：10086通过/2失败/6既有skip，3414.466秒，完整XML；首次DeepSeek HTTP观察差异和settled-reader测试DNS等待超时导致拒绝，后续发行阶段未开始。原首次观察被旧临时夹具删除，原因不冒称已证实；新增失败保留原始材料，不重试。数字IPv4避免不必要DNS线程，主机名可取消等待与原150/250ms判据保持；186实际HTTP/DeepSeek/重定向及14门禁/DNS分别通过。精确拒绝ZIP和有限修复材料独立核验归档。第四次新干净10095项/83配对/20组Source/实际解压及原版浏览器待执行，最新完整仍83026446/65，任务与例外不自动提升。

2026-10-08 第二次完整门禁13d0ae22在正常预算内取得完整XML：10082通过/6失败/6既有skip，3467.69秒；仍拒绝，Source/83配对/实际解压阶段未开始。精确ZIP/冻结输入/XML日志独立归档；旧reference构建、四项LLM提供过晚与长路径glob分别修复，16项profile/工作区及15项前端控制通过。本机实际official全构建产生33个绝对源码目录相关client差异，完整新产物归档后从历史已核验原记录/218字节恢复reference忽略环境，不改产品前端或原Source。第三次干净门禁待执行，任务状态与例外保持。见本日完整验证进展记录。

2026-10-08 按“先解决完整验证”优化并修复当前环境拒绝：干净 dea32b1c 收集10091项，正常3600秒约91%超时，无完整XML；实际ZIP/冻结输入/日志与进程退出独立归档，不签收。第二轮六处元数据解析与SQLite名称生成保留原谓词/完整默认观察输入，修复未开启系统长路径时的私有历史访问和夹具，以及浏览器UTF-8控制通道和显式Agent-owned Python导出扩展。164/3拒绝后30依赖回归通过，204格式/路径/消费者及51版本/目录操作分别通过，不合并重叠计数；新鲜完整正例校验约0.36–0.38秒仅为有限合成控制。预期10094项、83配对、20组Source与同包实际解压/原版浏览器待新的干净门禁，原预算/九项例外/16开放任务不变。见 `docs/research/2026-10-08-full-validation-performance-progress.md`。

2026-10-08 全量同步已核验：86 LFS 对象上传，master 正常快进至 b529a990，全部 6910079579 远端字节实际流式下载并核对大小/原 Git blob SHA1/SHA256。独立远程 clone 无 alternates/原 tip 对象，fsck、126 映射和 migration check 通过，Source pin 不变。22 成员小归档保存 producer/下载/克隆及原始全套诊断，不含认证 URL。干净 b529a990 的10046项正常3600秒67%超时，无完整XML，44存储/迁移控制执行通过但不宣称全套通过；输入/HEAD前后一致，进程树结束、工作区保留。初次GH009/502拒绝后重试成功；已验证克隆清理被自动审批 blocked by policy 拒绝而暂留。同步通过和全套超时分别入账，最新产品完整仍83026446/65，16开放任务及原版例外不变。见 `docs/research/2026-10-07-lfs-storage-progress.md` 与 `HANDOFF.md`。

2026-10-07 全量同步采用用户批准的Git LFS存储转换：只改126未推送提交，原tip02ad32af→74adf4c6，已发布9629973e和Source pin不变。86ZIP/6910079579字节保持原实际散列；完整裸仓库备份fsck通过，3352原始Git元数据对象及旧新映射公开保存。44实际回归包含真实LFS import和无旧commit对象的新clone；实际全图/归档证明、migration check通过。仅允许属性空行和精确跟踪规则差异，未知/篡改映射和产品改动仍拒绝；Windows指针恢复共享拒绝及初次属性证明拒绝均留存。CI下载LFS实体，旧回执身份不重标；上传/普通快进推送和完整回归结果另验，不计作迁移闭环。见 `docs/research/2026-10-07-lfs-storage-progress.md`。

2026-10-07 按用户要求收尾当前未提交的测量/研究材料并汇报整体状态：产品022852f5已干净；36成员完整正例测量与120成员路由/终止/路径/浏览器研究归档逐项核验。冷构造345.08秒、暖完整校验1.47秒，5279次路径解析为样本主要重复成本，优化尚未实施。七路由候选匹配，36终止/六路径为未推广研究，浏览器四处原始工具顺序差异仍保留为different。账本86项/70integrated/10running/6draft，最新完整仍83026446/65有界合同，不计算整体完成百分比。正常3600秒的10030项完整门禁65%超时，修复后5/35局部通过不替代完整验收。正确自动维护本次无新增合格材料，九项原版例外与延期认证不变。见 `docs/research/2026-10-07-current-work-close-status.md`。

2026-10-07 干净6aabea10收集10030项，在正常3600秒、65%时超时，无完整XML；两项既有失败由单项确认。脏目录拒绝前移到前端清单读取前，rg打包夹具使用完整已记录shell/client输入；5定向、35预检分别通过。951成员精确拒绝和17成员修复资格独立归档，收集器拒绝历史collection覆盖后只读恢复重新核验。自动清理932合成回执/12629254058字节；真实、未知和未结束输出保留。继续测量夹具成本后新干净完整门禁，不扩大预算或绕过。最新完整仍83026446/65，七父范围及延期认证保持。见 `docs/research/2026-10-07-frontend-preflight-order-progress.md`。

2026-10-07 完整门禁识别修复：真实pytest类方法XML原本被最后一段classname规则漏认，现显式绑定模块/类与完整测试名，错类/错模块和歧义等拒绝不放宽。121相关门禁控制及既有291项真实XML的四消费者识别通过；原拒绝、初次控制失败与干净2003821e主动中断的精确ZIP/输入/日志分别归档，未计为全量通过。继续新干净完整门禁，最新完整仍83026446/65。见 `docs/research/2026-10-07-class-method-gate-progress.md`。

2026-10-07 四处旧官方构建/Schema消费者预期修正，291实际回归和32正例先行的必需lane控制通过。干净46c8d4e1门禁早期失败后由协调器主动中断，完整输入/精确ZIP/原始日志及103通过4失败基线归档，未称全量通过；未结束工作区保留。新资格与拒绝分别独立归档，继续正常预算干净完整门禁。最新完整仍83026446/65，七父范围与延期认证不变。见 `docs/research/2026-10-07-official-frontend-consumers-progress.md`。

2026-10-07 原版完整前端和 settings500 修复：固定 Source 原样 build:official 的218 shell/client文件及完整环境摘要导入；公共 Schema refs 改为原版字符串键，严格编码器不放宽。320实际消费者、87预检/维护、53必需/解压控制及4原版浏览器生命周期通过；55新鲜Permission完整匹配。Source/Root三预设六条完整浏览器功能旅程完成真实工具/下一请求、问答/审批、取消、物理关闭和冷恢复。318文件归档保留HTTP500、通知拒绝、旧构建与checkpoint诊断；未把功能旅程当完整wire/own解释器资格。精确客户端副本双散列自动清理兼容十四/十八完整XML，真实/变更/未知/活跃材料保留。10007项全量已收集，新干净完整门禁继续执行；七父范围、036、056—064及延期认证不自动关闭。见docs/research/2026-10-07-official-frontend-progress.md。

2026-10-07 实际三预设提示补齐：文件引用完整路径/目录/引号规则及web_fetch不可信数据提示按原版恢复，68真实消费者通过。新鲜Source/Root/自有Python3.8.10完整组装匹配，2/26/33工具、473批准实际导入及15505完整自有字节守卫；安装根逐字验证后只投影其身份，同工作区/字面时间/会话和实际端口没有任意替换。47文件归档保留旧遗漏Agent诊断、Node观察器URI拒绝及浏览器通知超时拒绝。立即关闭的checkpoint closed警告继续定位，完整模型流/profile/浏览器及新冻结仍待验收，七父范围和延期认证不变。见docs/research/2026-10-07-preset-prompt-progress.md。

2026-10-07 默认Cordis多余export修复：manager只注册实际原版七项完整定义，Python导出保留为显式Agent拥有的插件；153真实导出/安装/合同回归、77通用门禁验证器通过。新鲜Source/Root/自有解释器92回调观察匹配，15505输入守卫通过；明确旧回调观察器没有完整导入枚举。SDK三链30/14/18帧及批准导入不变；41文件保留完整观察与精确字节。真实Web三预设组装顺序一致，另定位两段提示缺失，继续完整profile/原版浏览器/策略及七父范围；新完整冻结待验收，最新仍83026446/65。见docs/research/2026-10-07-cordis-export-extension-progress.md。

2026-10-07 Unicode实际载体064推进：FS UTF16截断产生的单独代理项此前导致mux内部错误、RPC400及模型网络前失败；三载体复用规范JSON编码。七输入/21完整Source/Root/自有Python3.8.10观察匹配，162批准导入/15501输入前后守卫；195真实消费者和74有效正例门禁通过。66文件独立归档保留所有拒绝及首轮catalog导入失败，最终局部传输导入另重新验收，第83配对接入。064及056—063仍running；完整Session/profile/原版浏览器/transport/恢复/竞争和新的完整冻结待验收，最新完整仍83026446/65，七父范围及延期认证不变。自动维护本轮没有新增合格材料，见docs/research/2026-10-07-unicode-carrier-progress.md。

2026-10-07 子代理model-selection063推进：16真实发布前setup配置、104完整Source/Root/自有Python3.8.10公开值匹配，120批准导入与15495输入前后守卫；27真实消费者及159有效正例后的正式/必需/解压控制通过。51文件归档保留320/152差异、漏value观察和首轮两项复制正则失败；真实Context拥有的Agent在工厂发布前注册工具，第82配对接入。063仍running；实际selected child routing、完整预设/原版浏览器/策略/取消/恢复/竞争及新完整冻结待验收，最新完整仍83026446/65，七父范围和延期认证不变。见docs/research/2026-10-07-subagent-model-values-progress.md。

2026-10-07 默认预设十项元数据推广：75真实消费者通过/一既有目录链接权限skip；新鲜实际Source/Root/自有Python3.8.10 headless31事件/3请求/4查询全部字段匹配，473批准导入与15488输入前后守卫。53文件独立归档保留完整观察和旧Git提供端字节，只允许完整UUIDv4分配引用图对应。完整profile父范围未闭合，继续可选子代理model-selection、minimal顺序、creative额外导出及正式profile/浏览器的问答/审批/取消/关闭/冷恢复；完整签收仍83026446/65，七父范围及延期认证不变。见docs/research/2026-10-07-profile-metadata-progress.md。

2026-10-07 FS062正式推进：六组509完整原版/精确Root字节自有Python3.8.10观察匹配，129批准导入/15488输入前后守卫；150前置通过/一既有POSIX跳过，127最终真实FS/SDK消费者和109有效基线门禁通过，不累计重叠。旧76负例基线无效明确撤销，FS/Message均补完整正例再篡改；SDK只批准两项新实际提供端导入，三链30/14/18帧不变。723文件保留全部原始拒绝和完整观察，81配对接入。062及056—061仍running，完整仍83026446/65；继续十项元数据/完整预设/浏览器/策略及七父范围，自动过期维护持续执行。见docs/research/2026-10-07-fs-tool-values-progress.md。

2026-10-07 实际AgentLoop模型发布继续修复：正常/中断消息调用真实构造器，完整UUID身份保留到下一请求，41定向消费者通过。新鲜隔离headless31事件/3请求/4查询严格匹配，473导入/15488输入守卫；候选另含18未推广提案，不能重标主目录预设签收。59文件保留短ID拒绝及新旧完整观察，两项新实际消费强制进入完整门禁。061仍running，继续工具元数据/FS及七父范围，完整冻结待验收；见docs/research/2026-10-07-assistant-allocation-progress.md。

2026-10-07 Message061正式推进：20完整新鲜原版/Root/自有Python3.8.10观察匹配，100批准导入与15481输入前后核验。四提供端修复完整UUID、字段选择、深层只读/循环克隆及运行时投影；实际字符串夹具按原版传内容块。427回归、95必需/解压控制和348实际消费各通过，不累计重叠；114文件保留原始拒绝、未完成XML及冷恢复失败。80配对，72新消费者/图和34门禁控制必需；061及056—060仍running，最新完整仍83026446/65。继续全部预设/浏览器/策略与七父范围，延期认证不变；自动过期维护本轮没有新增合格清理材料。见 `docs/research/2026-10-07-message-values-progress.md`。

2026-10-07 ask-user060正式推广：11项完整新鲜原版/主目录/自有Python3.8.10观察匹配，124导入、15481完整输入前后核验；65问答/计划/实际Web事件/客户端回归及446必需/解压控制通过，不累计重叠。真实questions依赖退役与类型化答案取代自动首项选择和本地handler回退；假Agent失败及正式旧主目录7项差异、较早11项研究分别保留，61文件归档。配对79项，新41消费者/25门禁控制必需。060及056—059仍running，最新完整干净签收仍83026446/65，继续Message构造/只读快照和完整预设/浏览器/策略及七父范围，延期认证不变。见 `docs/research/2026-10-07-ask-user-protocol-progress.md`。

2026-10-07 AgentLoop五依赖059正式推广：36项完整原版/主目录/自有Python3.8.10观察逐字段匹配，105个批准导入、15481个完整输入前后核验；498消费者、417补充、465必需/解压控制分别通过，不累计重叠。恢复真实Agent/Session/LLM provider，移除循环私建服务回退；80文件归档保留失败和零测试调用及不可变25文件先期研究。配对78项，新65消费者/24门禁控制接入。059及056/057/058仍running，最新干净完整签收仍83026446/65；继续ask-user、完整预设/浏览器/策略及七父范围，用户延期认证不变。自动过期维护继续运行并保留真实证据，见 `docs/research/2026-10-07-agent-dependency-lifecycle-progress.md`。

2026-10-07 工具结果058正式推广：12完整新鲜Source/Root/精确字节自有Python3.8.10观察匹配，105导入及15481输入前后核验；558定向、66排序/Session和168规范LLM/SDK回归各通过，不累计重叠。精确0b旧ZIP重解压拒绝、首版前缀UUID及正式LF/CRLF字节拒绝均保留，61文件资格嵌套不可变35文件早期记录。新配对77及全部新强制/解压控制接入；058/056/057仍running，新的干净完整发布待签收，七父范围及用户延期认证不变。见 `docs/research/2026-10-07-tool-durable-publication-progress.md`。

2026-10-07 路径解析维护资格：307项实际Source/原生/解压/必需控制通过，十项真实正常/悬空目录链接及实时文件回归成为强制lane；首版悬空链接拒绝保留。SDK/Permission仅对单次元数据校验中的缺失首级目录减少重复解析，真实文件散列/存在或重解析目录行为不变，helper字节加入新鲜Source守卫与便携验收复制清单。44文件资格独立归档；不以4000路径的有限基准宣称整批加速，不签收新的发布。056/057及七父范围仍开放，见 `docs/research/2026-10-07-import-path-resolution-progress.md`。

2026-10-07 完整直接回归：91262f92加六行合成SDK/Permission fixture映射压缩，9277 passed、6既有skip、零失败/错误，3556.59秒；785文件归档完整XML/日志/精确被测diff及768份自动清理审计。自动删除2571个可重建过程文件/10243133558字节，真实证据保留。该回归不替代干净冻结发布；057/056继续running，最新完整签收仍83026446/65。durable12/19拒绝与五依赖36隔离研究继续正式推广，原始悬空目录链接优化拒绝保留；七父范围及用户延期Win7/目标浏览器未关闭。见 `docs/research/2026-10-07-tools-sdk-full-regression-progress.md`。

2026-10-07 干净0b197efa全量9283项到91%因正常3600秒拒绝，此前已有七项失败，无完整XML/通过数；781文件保留精确ZIP/输入/原始退出。五处真实SystemPrompt前置依赖修正通过293回归及新鲜Abort56、Guard117匹配/两既有精确绕过、Timeout10；30文件资格保留完整七失败基线。自动清理2571个可重建文件/12136707871字节，保留实际证据。继续测量全量瓶颈，未扩大预算或绕过，057/056及七父范围仍开放。见 `docs/research/2026-10-07-tool-errors-sdk-metadata-progress.md`。

2026-10-07 Tools/SDK修订2补齐真实Loader恢复链：九项完整Source和八项SDK观察由自有Python3.8.10匹配，十五篡改拒绝，candidate2恢复失败原样保留。Tools每代重新注册，AgentLoop等待Tools而不抢占回退；862消费者与33解压/必需lane控制通过，97文件资格链接此前84文件精确基包。057仍running，新的干净全量/76配对/20组Source/实际解压/原版浏览器待签收；其余AgentLoop依赖与durable/ask-user/profile仍开放。自动过期维护本次无新增合格材料，保留真实证据。见 `docs/research/2026-10-07-tool-errors-sdk-metadata-progress.md`。

2026-10-07 Tools公开错误与必需systemPrompt依赖已推广，导出SDK先声明静态依赖并保留挂载globals/句柄，首版恢复回退独立拒绝。新鲜Source八完整观察、自有Python3.8.10和十四篡改控制通过；84文件精确资格保留，新增解压与必需lane门禁。057running，等待无重负载并行的全量及76配对/20组Source/实际解压/原版浏览器；durable旧错误载体及完整预设仍开放。旧466日志94%已有物理树F，不能解释为仅超时；隔离复测通过，原拒绝不改写。见 `docs/research/2026-10-07-tool-errors-sdk-metadata-progress.md`。

2026-10-07 自动过期维护继续完成：九份历史执行清理2568个合成JSON/27413212833字节，两份已结束资格目录清理30962个原样副本/491955312字节；57文件维护归档保留真实材料，缺XML执行先拒绝。干净466完整门禁收集9202项，到99%因正常3600秒时限拒绝，无完整XML；精确ZIP/输入/原始退出与逐项审计共759文件保留，未增加时限或计作签收。最新完整仍83026446/65，056running、036partial、七父范围及延期Win7不变。见 `docs/research/2026-10-07-expired-process-and-console-timeout.md`。

2026-10-07 Windows受限控制台提供端推进：有控制台时继承stdio/console，无控制台管道继续CREATE_NO_WINDOW；仍限制token、先挂Job后恢复、关闭拥有进程。启动nonce先输出空行并保持严格独立行拒绝判据；实际history拒绝原样保留。Root七项物理/nonce控制和35项相关回归通过，414文件原始研究资格保留。2738必需lane/75配对及新的干净完整验收待执行；功能浏览器研究不等于完整DTO/工具schema签收，七父范围、056 running及Win7延期保持。见 `docs/research/2026-10-07-confined-console-progress.md`。

2026-10-07 干净94a34b5d完整门禁被拒绝：8770 passed、45 failed、356 errors、6既有skip；磁盘峰值及两项旧审批审计断言分别处理。预检原样frontend/ICU副本改为每项body结束即双哈希清理，真实失败变体、活动/未知/外部文件保留；76项定向维护/真实子进程/审批/门禁控制通过。744文件精确拒绝归档保留，056仍running，最新完整仍83026446/65。见 `docs/research/2026-10-07-per-case-retention-progress.md`。

2026-10-07 下一部分056已推广：权限默认推导、严格投影、设置schema图及可逆命令/设置/投影所有权按实际原版对齐，空/数值表键边界保留。55组新鲜Source/Root/独立新ZIP自有Python3.8.10完整匹配，119实际导入字节核验；192消费者/解压/必需门禁控制与227既有回归通过，70文件资格包含精确ZIP和历史失败。056仍running，75实际配对与新的干净全量门禁待签收；最新完整仍83026446/65，七父范围、036partial及延期Win7不变。见 `docs/research/2026-10-07-permission-presets-progress.md`。

2026-10-07 流断开fixture责任另闭合一部分：真实创建栈定位模拟LLM服务器client_closed路径仍进入下一次HTTP读取；两条实际断流控制修复前确定失败。现client_closed/reset及主动销毁均结束handler读取，正常completed仍可复用同连接两次；48项相关回归通过。原始诊断/失败/前后字节独立归档。另有stall关闭及正常请求后的idle reset诊断仍保留，未吞错或宣称全局socket异常消除；最新完整签收仍83026446/65。

2026-10-07 Proactor既有warning已定位到WebServer契约测试自身：实际创建栈证明成功升级后的客户端writer未关闭，直到下一项测试所在循环已关闭后析构。原有客户端所有权控制确定失败；成功和中断两条关闭控制加入回归，固定fixture终于关闭并等待，不修改提供端/Source或屏蔽warning。修复后240项同范围实际诊断回归通过且没有Proactor异常记录；原始前后日志/XML/创建栈独立归档。socketserver10054及1175/5原因继续开放；最新完整签收仍83026446/65，fixture修复待下一完整门禁。见 `docs/research/2026-10-07-proactor-fixture-progress.md`。

2026-10-07 最新干净签收 `83026446`：完整8975 passed、6既有skip、1既有warning、0失败/错误，3088.56秒；2522必需lane、74实际配对、20组1911原样Source断言及真实解压自有Python3.8.10/原版浏览器均通过。052选定JS异常边界、054 Windows元数据、055 minimal SDK三链已有界integrated，共65份独立验收；036保持partial、七父范围继续开放。独立精确ZIP/输入/XML/观察及32份历史归档哈希核验保留。本轮自动清理660个合成JSON9030378843字节、1817个重复预检副本744448390字节；真实证据、失败变体及未知文件保留。Proactor warning、WinError1175及WinError5原因尚未闭合，不新增绕过；延期Win7与accepted_upstream空不变。见 `reviews/SDK-RETENTION-GATE-20261007.md`。

2026-10-07 下一部分052已推广：JS编译异常在原版Session边界于Ready前返回，原生继承stack保留真实业务消息/帧与own属性。规范C/workflow构建实际复现，无忽略候选输入路径。32实际Source/native及新ownZIP自有Python3.8.10观察匹配，22导入/20私有资源核验ZIP；191兼容/解压/必需拒绝控制与181既有回归通过。首次接入28失败原始XML日志保留，修正离线控制解释器模型及旧固定19资源检查，不修改Source/九条缺陷豁免。2522必需lane/74配对、全量8981项；052/054/055待新的干净完整签收，最新842/62及七父范围不变。见 `docs/research/2026-10-07-js-errors-progress.md`。

2026-10-07 过期预检frontend/ICU副本纳入自动维护：完整XML十四成功用例、目录归属/退出、冻结输入与原始文件双哈希、重解析点及删除前变化控制；正常pytest父进程收尾、下一次门禁前及维护CLI共用规则。实际清理十一份历史执行19987个副本/8188932290字节，真实证据/失败变体保留。79项维护控制、12项工作区及四项逐lane门禁拒绝控制通过，2425必需lane/73配对，预期全量8884项；两次组合的目录收取WinError5原始证据独立保留，持有者/原因未确认，不加重试/吞错。最新842/62、054/055 running及七父范围不变。见 `docs/research/2026-10-07-preflight-copy-retention-progress.md`。

2026-10-07 干净f5087dcd全量正常8841 passed、1 failed、6既有skip、1既有warning、3413.28秒；JS dropped-child观察在agent-end/child-dispose间竞争使完整门禁拒绝。精确ZIP/冻结输入/XML日志/原始Source与native帧及633项清理审计独立归档。双方改为terminal、语义边界和唯一子任务处置均完成后固定完整快照，原始收尾继续保留；50项实际会话/拒绝/边界控制通过。十项加入必需注册表，产品/Source/豁免/期限不变；新的干净全量待执行。054/055保持running，最新842/62不变。另按持续授权完成38228个已结束重复副本的哈希清理，释放3469744856字节。见 `docs/research/2026-10-07-workflow-session-boundary-progress.md`。

2026-10-07 干净14be4e66全量正常结束：8837 passed、6既有skip、1既有warning、0失败/错误、3093.13秒；门禁随后因中文stat参数ID在pytest XML中被转义而拒绝，后续Source/配对/解压/浏览器未执行。精确ZIP/冻结输入/完整XML日志/633项完成清理审计独立保留。必需注册表改为实际pytest转义ID，五个真实子进程通过/缺失/跳过/重复/失败控制通过，不改业务提供端或Source判据。新的干净全量待执行；054/055保持running，最新签收842/62不变。

2026-10-07 干净dc825e18全量在99%达到3200秒，被完整门禁拒绝；没有完整XML/正常退出，不推断通过数量，后续Source/配对/解压/浏览器未执行。精确ZIP/冻结输入/日志/进程退出及633项已完成单项清理审计独立归档，实际删除633合成JSON8597319926字节；真实证据保留，未残留合成回执。因实际新增覆盖及清理耗时，整批预算明确3200→3600秒，单项期限/Source判据不变；下次验收单独运行。054/055仍running，最新签收842/62和七父范围不变。

2026-10-06 过期合成回执改为门禁单项测试完成后及时清理，真实观察/失败XML日志/ZIP及外部路径保留。七项单目录控制和四个实际成功/失败、内部/外部子进程通过；71相关回归及扩展四子进程通过，51正式SDK解压/必需/正向门禁327.45秒通过。逐项审计保留，严格2384必需lane/73配对，全量收集8843项；整批预算因新增106 SDK和11维护控制及清理耗时明确2800→3200秒，单项期限/Source判据不变。最新签收仍842/62，新的干净完整验收待执行。

2026-10-06 下一部分055已推广：minimal SDK正常真实shell→下一请求、取消及断流完整30/14/18帧在实际原版/原生及新构建包自有Python3.8.10匹配，全部实际导入字节核验ZIP。五处提供端修正、56消费者控制、51解压/必需/正向门禁、54既有回归、12编辑器行为及28迁移控制通过；三份独立资格归档保留。全量收集8832项，2373必需lane/73实际配对/20组1911Source待新的干净完整验收；055和054仍running，最新签收842d6373/62，七父范围、1175与延期Win7开放。自动清理继续保留真实证据，后续控制过期合成JSON峰值。见 `docs/research/2026-10-06-sdk-profile-progress.md`。

2026-10-06 干净0076ec43全量XML为8709 passed、6既有skip、0失败/错误、2678.481秒，但pytest收尾清理达到2800秒期限，完整门禁拒绝；后续Source/72配对/真实解压/浏览器未执行。精确ZIP、16156冻结输入、XML/日志、进程退出及原始planned/恢复389项清理独立归档。现改为正常pytest退出并保留目录后由父进程清理，测试期限与分类/哈希/所有权判据不变；新的干净完整验收待执行。054仍running，最新签收842d6373/62，七父范围、1175及延期Win7开放。SDK三条完整链在五处隔离修正与显式非发布便携夹具匹配，正式54控制/54既有回归通过，尚未推广签收。

2026-10-06 下一部分054已推广：Windows文件版本使用真实ChangeTime/100ns元数据，公共stat目录大小按原版保留，句柄在成功/两条失败边界均释放。七组完整Source/native和真实解压自有Python3.8.10观察匹配；68新控制、1000门禁回归及80/101相关回归通过，两份资格ZIP独立保留。现8709项收集/2253必需lane/72实际配对，新的干净完整门禁待执行，054仍running。最新完整签收仍842d6373/62有界范围；七父范围、1175归因与延期Win7继续开放。见 `docs/research/2026-10-06-win32-stat-progress.md`。

2026-10-06 最新干净签收 `842d6373`：全量8635 passed、6既有skip、1既有warning、0失败/错误，2738.06秒；2185必需lane、71实际配对、20组1911原样Source及真实解压自有Python3.8.10/原版浏览器通过。051公共准备108组、053独立配置26组已有界integrated，共62份独立验收；20份历史归档逐项不变。自动清理559个可重建JSON释放6473952361字节，真实证据与审计保留；后续自动维护未发现新的合格过期清单。见 `reviews/LLM-CONFIG-GATE-20261006.md`。七父范围、036原始JS适配、1175原因与延期Win7仍开放；SDK正常/取消/断流和文件版本修正已隔离验证，继续推广。

2026-10-06 干净2d8fed63全量正常结束但拒绝：8634 passed、1项subagent预检旧错误文案测试失败、6既有skip、1既有Proactor warning，2754.16秒。精确ZIP/冻结输入/完整XML/原始失败fixture与实际原版/原生公共NO_ADAPTER诊断独立归档；559个合成JSON、6473952361字节自动清理审计保留。提供端不变，旧宽泛正则改为严格错误类型、代码、完整消息和Python诊断断言，31项定向回归通过。新的干净8641项/2185必需lane/71配对/20组1911Source及真实解压验收待执行；051/053仍running，最新签收2a/60，七父范围开放。见 `docs/research/2026-10-06-llm-config-progress.md`。

2026-10-06 下一部分053已推广：独立配置查询保持原对象/条件浅拷贝，公共准备与查询共享严格null/default/boolean校验。Root新鲜26项完整Source/native、108项既有prepared观察匹配，95项消费者/解压/必需lane拒绝控制及336相关回归通过；资格归档独立保留，尚非新包整批签收。8641项全量已收集，2185必需lane/71配对/20组1911原样Source待新的干净完整验收。051/053保持running，最新签收2a/60，七父范围及延期Win7开放；见 `docs/research/2026-10-06-llm-config-progress.md`。

2026-10-06 干净011c3a95完整回归拒绝：8530 passed、1 WinError1175失败、6既有skip、1既有warning，2675.50秒。精确ZIP/冻结输入/完整XML/日志/失败目标及528项自动清理审计独立保留。受控原版/原生共享句柄复现32并证明释放后恢复，没有复现1175或识别原始持有者；公共Windows错误字段按原版对齐，九条严格必需控制及51相关回归通过，961项门禁/迁移校验通过，不加重试或bug绕过。最新签收仍2a/60，051及七父范围开放，继续053及完整工具/profile验收。见 `docs/research/2026-10-06-win32-replacement-progress.md`。

2026-10-06 干净fb3ba8d9全量正常结束但拒绝：8527 passed、2项module-fallback测试预期失败、6既有skip、1既有Proactor warning，2650.16秒。精确ZIP/冻结输入/完整XML/日志及528项合成JSON清理审计已独立归档。原版依赖安装后可见的Node依赖被旧预期遗漏，扫描上限20也不是原版合同；现独立按最近anchor解析dependencies/peers，缓存检查唯一workspace和再次零扫描，并增加两项确定性回归。新的干净8537项/2081必需lane/70配对验收待完成；最新签收仍2a/60，051及七父范围开放。隔离图片34完整观察、29原样Source断言、139相关回归通过，真实headless已注册齐25个工具，仍有17项参数及权限/组合差异；这些尚未签收。

2026-10-06 干净c0b12c55门禁再次拒绝：完整8531项XML为8516 passed、9共享Source输入扫描错误、6既有skip、0 failed；测试2666.098秒后清理达到2800秒期限。精确ZIP/冻结输入/原始错误/中断审计已归档；Git tracked输入枚举、清理避免重复JSON解析及中断续清修复50定向通过，恢复清理实际299项约3.2 GiB。新全量8535项/2081必需lane/70配对待干净验收，051仍running；最新签收仍2a/60，七父范围和延期Win7开放。完整headless实际工具研究确认新的权限/调度/组合差异，仍隔离未签收；见 `docs/research/2026-10-06-llm-prepared-progress.md`。

2026-10-06 `b93d1cd8` 完整8531项门禁被拒绝：8521 passed、4 failed、6既有skip、2 warnings，2686.04秒。三项ACP fixture改用规范适配器注册、正向门禁计数从严格2077注册表计算后107定向通过；精确拒绝ZIP/完整冻结输入/XML/日志/18份ACP实际fixture独立保留。自动清理528个合成JSON释放约5.66 GiB并保留真实证据。051仍running，下一干净全量/Source/实际解压待执行；最新签收仍2a/60，七父范围和延期Win7保持开放。见 `docs/research/2026-10-06-llm-prepared-progress.md`。

2026-10-06 下一部分051：108完整公共prepared-call/代际/严格配置/规范AgentLoop观察隔离匹配，精确2a自有Portable确认49真实差异。正式143新控制及419公共消费者、336相关回归通过；178新必需lane预计总2077/70实际配对，六个新增真实导入已严格测量补齐。051仍running，须新干净全量/实际解压/原版浏览器后才签收；见 `docs/research/2026-10-06-llm-prepared-progress.md`。最新签收仍2a67ae84/60有界合同，七父范围、原始JS诊断和延期Win7继续开放。

2026-10-06 最新干净签收 `2a67ae84`：全量8347 passed、6既有skip、1 warning、0失败/错误，2539.22秒；1899必需lane、20组1911原样Source断言、69实际配对及真实解压自有Python3.8.10/原版浏览器通过。049选定137组公共元数据/最终请求及050自动清理/进程超时维护已有界integrated，共60份独立验收。上次9b全量超时与精确ZIP独立保留；本次整批预算明确2800秒。见 `migration/reviews/METADATA-RETENTION-GATE-20261006.md`。公共prepared-call的101完整隔离观察和336回归通过，尚未推广签收。七父范围、原始JS诊断差异、九项判据/C58/C59、accepted_upstream空和延期Win7继续开放。

2026-10-06 当前推进：干净9b3f773b在整批pytest2400秒、94%处被拒绝，没有完整XML或通过数量；目录保留WinError5遮蔽了主超时。精确失败产物已提交be8c2e53，049仍running。050现接入正式pytest收尾与门禁启动自动清理，删除仅限可重建合成回执，真实验收/失败/Source证据保留；50定向与28迁移回归通过，全量收集8353项。整批预算明确2400→2800秒，1899必需lane/69配对/20组1911原样Source；单项期限及九判据/C58/C59不变。新的干净完整验收待执行，最新签收仍55a5ba87/58有界范围。公共prepared-call隔离87完整观察及336回归通过，尚未推广。七父范围、八项JS差异与延期Win7继续开放；见docs/research/2026-10-06-process-artifact-retention-progress.md。

2026-10-06 下一独立部分049：公共LLM元数据137完整观察隔离匹配，81既有规范消费者与336定向回归通过；精确55a自有Portable保留44/92公共和23/45最终流式差异，逐项导入匹配ZIP/冻结输入。正式137与192新必需控制已推广待定向/完整验证；规划1853lane、69配对、20组1911原样Source，049保持running。准备句柄15原版观察为下一部分研究；七父范围/八项JS差异/九判据/C58/C59/accepted_upstream空及延期Win7不变。见docs/research/2026-10-06-llm-metadata-progress.md。

2026-10-06 最新干净签收 `55a5ba87`：全量8109 passed、6既有skip、1既有Proactor warning、0失败/错误，2297.10秒；1661必需lane、20组1911原样Source断言、68实际配对及真实解压自有Python3.8.10/原版浏览器通过。048选定81组规范重试/失败/准备/迭代归属已有界integrated，共58份独立验收；所有精确旧产物/正式v1缺项拒绝保留，未放宽九项判据/C58/C59。见 `migration/reviews/CANONICAL-LLM-GATE-20261006.md`。下一公共元数据137完整观察隔离匹配、81既有规范消费者及336回归通过，尚未进入本签收。七父范围、八项原始JS差异、accepted_upstream空与延期Win7继续开放。

2026-10-06 下一独立部分048：canonical LLM四模块隔离81组完整Source观察匹配，305相关消费者通过；精确拒绝eaa8自有Portable新54/9/7控制保留51/9/4差异并核验每个实际导入。正式81组/逐组模块/篡改/解压收据推广后须定向及独立干净完整验收；规划1661必需lane、68配对、20组1911原样Source。048仍running，最新签收b2398db9/57有界范围；七父范围、八项JS差异、九项判据/C58/C59、accepted_upstream空和延期Win7不变。见docs/research/2026-10-06-canonical-llm-progress.md。

2026-10-06 最新干净签收 `b2398db9`：全量7967 passed、6既有skip、1既有Proactor warning、0失败/错误，2212.32秒；1519必需lane、十九组1683原样Source断言、67实际配对及真实解压自有Python3.8.10/原版浏览器通过。046完整选定76诊断、047四组JSONL共享读取已有界integrated，共57份独立验收；精确eaa8拒绝与历史产物不改写，原始临时持有者未识别。见 `migration/reviews/JSONL-SHARING-GATE-20261006.md`。下一canonical LLM四模块隔离研究81完整观察匹配，305相关回归通过，尚未进入本签收。七父范围、八项JS差异、九项判据/C58/C59、accepted_upstream空及延期Win7不变。

2026-10-06 新候选eaa8bb05全量被拒绝：7921 passed、1 forked-session JSONL列举Errno13、6既有skip、1既有warning，2168.22秒；精确产物已归档。受控Win32持有者复现CRT共享差异，原版读取成功；原始临时持有者未识别。047修复四组观察匹配、28定向回归通过，970扩大回归全通过（583.95秒、0 skip/failed）；下一独立干净候选1519必需lane/67配对/19组1683原样Source和真实解压/原版浏览器须全通过。046/047仍running；最新签收54361bd9/55有界范围。canonical retry四模块修复仅隔离研究，七父范围与整体/延期Win7仍开放，九项判据/C58/C59不变。见docs/research/2026-10-06-jsonl-sharing-progress.md。

2026-10-06 最新干净签收 `54361bd9`：全量7760 passed、6既有skip、1既有Proactor warning、0失败/错误，2045.67秒；1312必需lane、十九组1683原样Source断言、65实际配对及真实解压自有Python3.8.10/原版浏览器通过。044完整请求与045错误诊断已有界integrated，共55份独立验收；精确afd失败与此前产物不改写。见 `migration/reviews/DEEPSEEK-ERROR-GATE-20261006.md`。下一76旧wire范围的精确543自有Portable仍有17诊断差异，隔离副本匹配76并通过78旧消费者，尚未推广签收；继续七个父范围、八项JS差异和完整B/C/D。九项判据/C58/C59、accepted_upstream空和延期Win7不变。

2026-10-06 DeepSeek错误045已推广：24实际原版/原生完整HTTP观察匹配，914相关回归通过；五个畸形SSE/三个超时文本差异由精确未修改afd85f4e自有Portable复现。新增446原样DeepSeek/retry断言通过。现1312必需lane、十九组1683原样断言、65配对；独立提交后须完整冻结及真实解压/浏览器验收，044/045仍running。JSON只对同值整数token2000/2000.0统一摘要，完整错误/请求/块/失败值与原始报告保留，额外语言异常属性/堆栈未认证。路径部分已提交3a7b2da5，最新签收仍7f9e87e4/53范围。见 `docs/research/2026-10-06-deepseek-error-progress.md`；全部父范围、八项JS差异、九项判据与延期Win7不变。

2026-10-06 完整请求候选 `afd85f4e` 被门禁拒绝：7678 passed、1真实Git路径失败、6既有skip、1既有warning，1978.05秒；精确Portable/输入/XML/失败fixture已独立归档。输出标签扩大pytest执行路径触发 `$GIT_DIR too big`；相同长度复现失败，短路径通过。门禁改用自有短执行目录并保存原路径→归档路径映射，87项相关回归通过；现1234必需lane/64配对/十八组1237原样断言，新完整验收待执行。044保持running，最新签收仍7f9e87e4/53有界范围。下一部分DeepSeek错误24观察有8真实差异、隔离匹配24，446原样Source断言通过，尚未推广签收；见 `docs/research/2026-10-06-release-pytest-path-progress.md`。九项判据、整体与延期Win7不变。

2026-10-06 最新干净门禁：产品 `7f9e87e4` 全量7615 passed、6既有 skips、1既有 Proactor warning、0 failed；1167必需lane、十八组1237原样Source断言、63实际配对及真实解压自有Python3.8.10/原版浏览器全部通过。040入口/初始管道退出、041修订2数值/冻结发布/可变克隆、042精确准入错误和043恢复数值符号已有界 integrated；53份单独回执及精确产物归档，4a127b73失败仍独立保留。见 `reviews/SESSION-BOUNDARIES-GATE-20261006.md`。下一部分已复现完整模型请求中的tool_calls/max_tokens/reasoning_effort旧别名，隔离16观察匹配但未进入本签收。父Session/JS036/完整B/C/D、accepted_upstream与延期Win7仍开放；九项原版缺陷判据/C58/C59不变。

2026-10-06 待冻结的新产品部分：副本修复ddc45529、精确准入错误b76d42f5已分别提交；恢复数值符号修复的18 Source观察匹配，扩大1457项回归通过。当前1167必需lane、63配对和十八组1237原样Source断言，040至043须共同通过不同干净候选全量/实际解压/原版浏览器后才签收；最新完整签收仍为47adea37。精确4a127b73的克隆两项、诊断30项、恢复符号四项差异均由其未修改Portable重新解压复现，旧失败不改写。见三个2026-10-06 Session进展记录；父Session/JS036/完整B/C/D及延期Win7保持开放。

2026-10-06 新候选 `4a127b73` 被完整门禁拒绝：7407 passed、10 failed、6既有 skips、1既有 warning；冻结错误传播到实际查询副本。精确失败Portable/输入/XML/日志保留。修订2按实际Source的浅复制/structuredClone修复归属，53组完整观察匹配，扩大1269项回归通过；当前979必需lane、61配对，新的完整冻结验收仍待执行。040/041保持running，最新完整签收仍为47adea37。见 `docs/research/2026-10-06-session-header-clone-progress.md`；九项原版缺陷判据与延期Win7不变。

2026-10-06 最新干净门禁：产品 `47adea37` 全量7271 passed、6既有 skips、1既有 Proactor warning、0 failed；823必需lane、十八组1237原样Source断言、59实际配对及真实解压Python3.8.10/原版浏览器通过。037每步具名运行时上下文、038已发出Ready跨退出及039规范JSONL/SQLite公共读取51组已有界 integrated；49份任务回执绑定确切产物。整批pytest预算显式1800→2400秒，单项期限和九项原版判据/C58/C59不变；旧3be2漏报F及7060解释器拒绝失败独立保留。见 `reviews/RUNTIME-CONTEXT-READ-GATE-20261006.md`。新的初始管道退出和公共Session元数据差异仅完成隔离研究，未进入47adea签收；JS036、完整B/C/D、accepted_upstream及延期Win7仍开放。

2026-10-05 最新干净门禁：产品 `b1b2f797` 全量7087 passed、6既有 skips、1既有 Proactor warning、0 failed；639必需lane、十八组1237原样Source断言、56实际配对与真实解压Python3.8.10/原版浏览器通过。实际进程退出与协议失败的分类已修复；34组Source/native/extracted宿主完整观察验证发布前后、Result后与取消后的退出码、首个结果及child清理。46既有范围重验，036继续只记录部分verification，完整model/profile、ready前竞争、八项原始engine/parse差异及完整C2/B/C/D继续开放。见 `reviews/JS-WORKER-DEATH-GATE-20261005.md`；accepted_upstream仍为空，Win7仍延期。

2026-10-05 最新干净门禁：产品 `17c1c521` 全量7077 passed、6既有 skips、1既有 Proactor warning、0 failed；629必需lane、十八组1237原样Source断言、56实际配对及真实解压Python3.8.10/原版浏览器通过。四十六个既有有界合同重验；真实私有JS、原版worker/宿主算法与规范Windows workflow/Ralph已进入产品并通过30场景完整观察和19项私有资源来源检查，但036只记录部分verification，完整合同仍running。八项原始engine/parse差异、全model/profile及竞争边界、完整C2/B/C/D和accepted_upstream仍开放。见 `reviews/JS-WORKFLOW-GATE-20261005.md`；Win7继续延期。

2026-10-05 最新有界签收：干净产品 `6ceef0f9` 完整门禁6944 passed、6既有 skips、1既有 Proactor warning、0 failed；496必需 lane、十八组1237原样 Source断言、55实际配对和真实解压/原版浏览器通过。dispatch启动前缀034与HTTP重定向035有界 integrated，四十六份任务证据及确切产物归档；见 `reviews/TOOLS-HTTP-CLOSURE-20261005.md`。九项原版缺陷判据、旧失败及此前清理记录保持不变。完整B/C/D与整体 accepted_upstream继续开放，通用JS实际引擎仍在研究，Win7仍延期。

2026-10-05 当前有界签收：干净产品 `1f180e40` 完整门禁通过，6892 passed、6既有 skips、1既有 Proactor warning、0 failed；444必需 lane、十八组1237原样 Source断言、54双侧驱动及真实解压/原版浏览器通过。规范 schema19 SQLite323、默认压缩 JSONL1030、并发/settings22和只读差分已有界 integrated，四十四份任务证据绑定确切产品和输入；见 `reviews/SESSION-STORAGE-CLOSURE-20261005.md`。七个确切拒绝产品、真实诊断和两份授权合成回执清理记录保留。完整B1/B2/B3、C/D、历史未归因问题和整体 accepted_upstream继续开放，Win7仍延期。

2026-10-05 SQLite 格式：干净产品 `0edcc616` 完整冻结门禁 **6718 passed、6 existing platform skips、1 existing warning、0 failures/errors**；337 必需 lane、十五组 1124 原版断言、51 双侧驱动及实际解压/浏览器通过。独立 schema-19 格式的 826 观察和 42 原样压缩断言已有界签收，四十份任务回执与确切 Portable 归档 `evidence/artifacts/SQLITE-FORMAT-20261005-0edcc616.zip`。见 `reviews/SQLITE-FORMAT-CLOSURE-20261005.md`；规范物理提供端、既有诊断和整体迁移继续开放，accepted_upstream 为空，Win7 延期。

本目录以 `tasks/*.json` 为状态权威，`status.md` 由工具生成。当前交付是单一协调者、契约依赖和只读门禁；分布式调度器、原子租约、自动上游巡检不属于本批次实现。

只读差分工具：`.venv\Scripts\python.exe scripts/upstream_delta.py --base <existing-ref> --target <existing-ref> [--output <new-file>]`。要求 unchanged pinned Source，输出原版 Git 差分、两侧最邻近 package、反向声明依赖和 non-package surfaces；不 fetch/checkout、修改 pin 或自动推进任务。影响是建议性资料，不是完整动态职责图或迁移签收。见 `docs/research/2026-10-05-upstream-delta-progress.md`；完整无缓存和外部验证另列。

## 当前补齐：2026-10-02

2026-10-05 可选 Session 工具完整签收：干净产品 `ae2c1abe` **6657 passed、6 既有平台 skipped、1 既有 Proactor warning、0 failed**；**312 必需 lane、十四组 1082 原版断言、50 配对与真实解压/原版浏览器**全部通过。五个工具的 78 实际原版/原生/解压观察和两种规范 profile 的模型调用/新 Context 冷恢复已有界验收；共同 `INVALID_ARGS` 消息在 Tools 提供端修正。39 份任务证据归档于 `evidence/artifacts/SESSION-TOOLS-20261005-ae2c1abe.zip`，历史拒绝产物保持独立可查。见 `reviews/SESSION-TOOLS-CLOSURE-20261005.md`。物理 schema-19、压缩、malformed/plugin ABI、竞争、B/C/D 与整体范围继续开放，`accepted_upstream` 仍为空。

2026-10-05 Unicode 与 Session 文本完整签收：干净产品 `fc275a66` **6598 passed、6 既有平台 skipped、1 既有 Proactor warning、0 failed**；**300 必需 lane、十三组 980 原版断言、49 配对与真实解压/原版浏览器**全部通过。2034 Unicode 身份与 7883 字面匹配/有效语义提取/当前 locale 顺序观察已有界验收，38 份任务证据归档于 `evidence/artifacts/SESSION-TEXT-20261005-fc275a66.zip`。同时保留 `34b8`、`e598` 精确拒绝产物和实际重绘点击诊断。见 `reviews/SESSION-TEXT-CLOSURE-20261005.md`。可选会话工具、malformed/plugin ABI、竞争、schema-19、B/C/D 与整体范围继续开放，`accepted_upstream` 仍为空。

2026-10-05 Unicode/Session 文本候选 `e5989dce` 被完整门禁拒绝：**6596 passed、1 failed、6 既有平台 skipped、1 既有 Proactor warning**。原版批准更新的物理点击未发出第二次批准请求；真实 inventory 响应受控暂停/恢复复现按钮上移 24px 后旧坐标落空。观察器等待正确版本绘制并验证可信点击命中，新增必需重绘边界用例，**489 项聚焦回归通过**。现要求 **300 必需 lane、980 原版断言、49 配对**；确切失败 ZIP/输入/截图已保留，新候选完整签收与 Unicode/文本验收仍待进行。见 `docs/research/2026-10-05-browser-approval-layout-progress.md`。

2026-10-04 规范 FTS 阶段完整签收：干净产品 `5c8c2c57` 门禁 **6458 passed、6 既有平台 skipped、1 既有 Proactor warning、0 failed**；**224 必需 lane、十三组 980 原版断言、47 双侧驱动及真实解压/原版浏览器**全部通过。三十六份有界任务证据归档于 `evidence/artifacts/SESSION-QUERY-ENGINE-20261004-5c8c2c57.zip`，同时签收先前待验收的搜索请求、快照、派生 schema、目录发布及 socket/Gateway 清理。见 `reviews/SESSION-QUERY-ENGINE-CLOSURE-20261004.md`。`24f9` 启动取消仍未归因；Unicode 指纹、完整提取、schema-19、B/C/D 与整体迁移继续开放，`accepted_upstream` 保持空。

2026-10-04 规范 FTS 引擎已精准整合：16 组真实原版/原生观察、实际 main/TEMP FTS、稳定两次观察、提供端代际、取消/关闭归属及三套 Web preset 的重启搜索通过 **562 项主树回归**，原版引擎另有 60 项原样断言通过。规范注册入口已接入新服务；新增实际解压来源校验和拒绝门禁，当前要求 **224 必需 lane、十三组 980 原版断言、47 双侧驱动**。完整冻结验收仍待执行，Unicode ICU 指纹、schema-19、独立启动取消和整体迁移未签收。见 `docs/research/2026-10-04-session-query-engine-progress.md`。

2026-10-04 查询 schema 候选 `24f9f83d` 被完整门禁拒绝：**6377 passed、1 failed、6 skipped、1 warning**。原版 Python 包旅程十二步业务完成后，最终页面的启动请求取消导致两条原版 console error；精确候选 ZIP/输入/浏览器诊断已保存。新增可选生命周期、fetch/signal 和加载 trace 诊断，没有修改原版前端、错误判据或增加 bug 绕过；诊断通过不签收失败候选。见 `docs/research/2026-10-04-web-startup-cancellation-progress.md`。最新签收仍为 `1d9940aa`，整体未闭环。

2026-10-04 派生查询 schema：官方 SQLite 3.51.2 私有 DLL、schema-8 STRICT/FTS5 及十九组真实双侧观察已精准整合，主树 535 项契约/门禁回归通过。两处 DLL 使用 Win7 普通加载路径；快照观察夹具显式设置两侧相同 ChangeTime，消除系统时钟粒度前提，原版实现和判据不变，首次失败原始输出保留。当前完整门禁要求 189 必需 lane、十二组 920 原版断言、46 双侧驱动和真实解压观察；须独立提交并冻结完整验收。最新签收仍为 `1d9940aa`，公共 FTS 引擎、完整迁移与延期 Win7 未认证。

2026-10-04 目录发布：干净候选 `bc7028c2` 为 **6289 passed、1 failed、6 skipped、1 warning**，全部原版浏览器与快照通过，初始本地 Python 包安装的目录发布遇到 WinError 5；精确候选 ZIP/输入/诊断已保留。有界共享等待、目录句柄归属及完整事务保留修复通过主树 518 项回归，增补 10 必需 lane 与实际解压观察，当前门禁 162 lane / 920 原版 / 45 配对。须提交并冻结新候选完整验收；最新签收仍为 `1d9940aa`，外部持有者未归因，未增加原版 bug 绕过。

2026-10-04 持久化快照：18 组真实原版/原生观察、Windows ChangeTime、SQLite incarnation/事务 counter 和实际解压观察已精准整合，主树 511 项契约/门禁及 48 项存储/缓存回归通过；保留主树 inspect 取消语义和两次 socket 清理修复。门禁增至 152 必需 lane、十二组 920 原版断言和 45 双侧驱动；须提交并冻结新候选完整验收，当前无新增签收，整体 `accepted_upstream` 仍为空。

2026-10-04 关闭路径继续调查：`ac31cd6a` 也被完整门禁拒绝，**6218 passed、3 failed、6 skipped、1 warning**。三条原版 Python 插件旅程在业务完成后报告对已关闭 socket 的发送；已保存该候选精确 ZIP/回执，并补齐源 Gateway 的锁内关闭检查与迟到迭代器排空。17 项隔离回归、主工作区全部 59 项浏览器/Gateway 定向回归及 414 项门禁回归通过；中间门禁增至 137 必需 lane。此修复仍待新候选完整验收；不屏蔽 warning，不重跑未改候选碰运气。持久化快照在隔离工作区有 18 组双侧和 591 项回归，尚未推广或签收。

2026-10-04 搜索请求候选 `a953a086` 的完整门禁被拒绝：**6195 passed、1 failed、6 skipped、1 warning**。第二个原版浏览器页面关闭后，Python 3.8.10 Proactor 的 `shutdown()` 重置错误跳过 close/detach 并触发 Host fail-loud；精确候选 ZIP 与失败回执已保留。服务自有 socket 清理修复通过 70 项定向回归及两条原版浏览器流程，并增加 7 必需 lane 和实际解压重置观察；必须另行冻结新候选完整验收。最新已签收仍为 `1d9940aa`，没有新增测试绕过；见 `docs/research/2026-10-04-webserver-peer-reset-progress.md`。

2026-10-04 Session filters：干净候选 `1d9940aa` 完整冻结门禁 **6134 passed、6 skipped、1 warning、0 failed**，119 必需 lane、十一组 910 原版断言、43 双侧驱动及真实解压观察通过。`CON-SESSION-FILTERS@1` 有界 integrated，三十一份任务证据归档 `evidence/artifacts/SESSION-FILTERS-20261004-1d9940aa.zip`，包括实际候选 Portable ZIP；见 `reviews/SESSION-FILTERS-CLOSURE-20261004.md`。搜索请求正在单独推进；完整 Unicode/FTS/代际、B/C/D、历史诊断与延期 Win7 仍未完成。

2026-10-04 Session tracing：干净候选 `5c0b3c5e` 完整冻结门禁 **6082 passed、6 skipped、1 warning、0 failed**，114 必需 lane、十一组 910 原版断言、42 双侧驱动及真实解压 Python 3.8.10/原版浏览器通过。三十个有界任务重签，包含此前未签收的 ACP subprocess/teardown、MCP disposal、进程树、cache/point/corpus/title、ZIP 暂存和谱系/事件窗口；证据见 `reviews/SESSION-TRACING-CLOSURE-20261004.md`。此前失败和源缓存 40ms 时序诊断均保留，没有新绕过或重试；过滤/完整 FTS、B/C/D、整体 accepted_upstream 与延期 Win7 仍开放。

2026-10-04 ACP/MCP：干净候选 `e24fe1db` 完整冻结门禁 **5508 passed、6 skipped、1 warning、0 failed**，62 必需 lane、七组 722 项原版断言、31 双侧驱动及真实解压会话 MCP 消费者通过。`CON-ACP-MCP@1` 有界 integrated，十九份证据归档 `evidence/artifacts/ACP-MCP-20261004-e24fe1db.zip`，见 `reviews/ACP-MCP-CLOSURE-20261004.md`。无限阻塞初始化、完整 URL/SDK、subprocess subagent、B/C/D、整体 accepted_upstream 与延期 Win7 仍开放；第五部分继续单独实施和验收。

2026-10-04 MCP：干净产品候选 `8a17485d` 完整冻结门禁 **5408 passed、6 skipped、1 warning、0 failed**，51 必需 lane、七组 722 项原版断言、30 双侧驱动及真实解压 stdio/HTTP 工具消费者通过。`CON-MCP-STDIO@1` 和 `CON-MCP-HTTP@1` 只按有界提供端范围 integrated，18 份合同证据归档 `evidence/artifacts/MCP-20261004-8a17485d.zip`；见 `reviews/MCP-CLOSURE-20261004.md`。此前 browser startup 取消及既有 Proactor/HTTP 10054 保留未归因，完整 SDK/ACP mounting/subagent/B/C/D、整体 accepted_upstream 与延期 Win7 未闭环。

2026-10-04 A4 权限：干净产品候选 `e887550a` 完整冻结门禁通过，**5020 passed、6 skipped、1 warning、0 failed**；20 条必需 lane、619 项原版断言、28 个双侧驱动及实际解压六条权限进程旅程通过。`CON-ACP-PERMISSIONS@1` 有界 integrated，10 组原始匹配及两组单独审阅的原版畸形 outcome 授权缺陷，证据包 `evidence/artifacts/ACP-PERMISSIONS-20261004-e887550a.zip`。见 `reviews/ACP-PERMISSIONS-CLOSURE-20261004.md`；既有 Proactor/HTTP 10054 诊断仍保留。MCP/subagent、B/C/D 和整体 accepted_upstream 未完成。

2026-10-03 A3：干净产品候选 `5edf7e22` 完整门禁通过：**4971 passed、6 skipped、1 warning、0 failed**；十四条必需 lane、六组 619 项未改动原版断言、27 个双侧驱动及实际解压 Portable 通过。`CON-ACP-STDIO@1` 已有界 integrated，涵盖 canonical acp-app、SDK wire/参数、真实进程 EOF 与关闭所有权；906 项 SDK/生产原始观察匹配。十五份证据及历史失败归档于 `evidence/artifacts/ACP-STDIO-20261003-5edf7e22.zip`，见 `reviews/ACP-STDIO-CLOSURE-20261003.md`。完整 ACP 的 MCP/权限/subagent 和 B/C/D 仍未完成；全项目 `accepted_upstream` 仍为空。

2026-10-03 后续：干净产品候选 `97f7b287` 已通过完整门禁，**4933 passed、6 skipped、1 warning、0 failed**，十条必需 browser/Portable lane、五组 616 项原样源码断言、26 个双侧驱动及实际解压 Portable 均通过。`CON-ACP-SESSION-CONTROLS@1` 和 `CON-ACP-CONFIG-OUTPUT@1` 的有界任务已 integrated；14 份当前证据及所有先前失败归档于 `evidence/artifacts/ACP-CONFIG-20261003-97f7b287.zip`。完整 ACP 仍待 canonical stdio 与 MCP/权限/subagent；没有认证全项目、fresh uncached bootstrap 或 Win7。详见 `reviews/ACP-CONTROLS-CONFIG-CLOSURE-20261003.md`。

本轮 `MIG-CURRENT-RELEASE-GATE-003` / `CON-CURRENT-RELEASE-GATE@1` 补齐当前原版浏览器、最新已选双侧契约及实际解压 Portable 统一验收；不是重签历史 `MIG-REPRO-GATE-002`，也不代表整个迁移完成。用户授权提交后，产品候选 `623a615a` 已通过干净门禁；当前门禁和 ACP prompt 归属两个有界任务已 integrated，历史十个 Core/Agent/Session/Spine/Portable 范围重签本候选证据。未提交预览仍不得进入 verified/integrated。

正式门禁必须提供 Chromium：`scripts/verify_release.py --browser <absolute-path>`；缺少浏览器、必需测试跳过、回执或候选不一致均拒绝发行。`--allow-dirty` 仅用于本地开发预览，其 summary 始终 `publishable=false`。原版浏览器只用真实可见控件完成无凭据引导，不修改上游 TSX/CSS；后续导航先等待有限请求结束，再检查弹窗或交互状态。

范围、既存缺口和后续顺序见 `docs/research/2026-10-02-migration-status-audit.md`；本轮推进与验证见 `docs/research/2026-10-02-current-gate-progress.md`。Windows 7、JS/OAuth 和 ACP 等仍按独立契约推进，不能用当前 Windows 门禁代替。

2026-10-03：按用户授权提交 P0 初版后的首次 clean gate 失败已保留；新增文档代际等待和完整诊断，并用四个失败探针修复单请求 HTTP carrier 隐瞒 socket 关闭的问题。修复后的 preview 与干净产品候选均 **4800 passed、6 skipped、1 warning**，十条必需 lane、四组原样源码测试、24 个双侧驱动和实际解压 runtime/browser 通过；只有后者为 passed / publishable=true。ACP 精确 Session/Agent/message/turn 归属通过 `MIG-ACP-PROMPT-OWNERSHIP-001` / `CON-ACP-PROMPT-OWNERSHIP@1` 验收，不冒充完整 ACP 实现。收据、完整输入、原始观察及历史失败归档于 `evidence/artifacts/CURRENT-GATE-20261003-623a615a.zip`；范围与后续行动见 `docs/research/2026-10-03-current-candidate-closure.md`。

原版 bug 的统一发现索引为 `upstream-bug-exceptions.json`：此前八类判据不变，新增第九类 `UPSTREAM-ACP-PERMISSION-001` 仅接受原版对两组畸形 outcome 错误授予 allow-once 的精确签名。索引指向配对 predicate、场景和独立审阅，不是跳过列表。C58 独立归入语言适配，迁移产生的 ACP 归属错误和观察器缺陷不登记为原版 bug；各门禁仍是唯一允许差异的执行权威。

## 操作

```powershell
.venv\Scripts\python.exe scripts/migration.py check
.venv\Scripts\python.exe scripts/migration.py ready
.venv\Scripts\python.exe scripts/migration.py status --write
.venv\Scripts\python.exe scripts/migration_inventory.py
```

`check` 校验记录、依赖环、契约 revision、证据哈希、固定上游 checkout 和 manifest 漂移；它不是 parity 测试。`ready` 只列出无阻塞任务，不领取任务、不提供租约。完整 inventory 重建要求固定上游 SHA 与 manifest 集合/内容未漂移。

## Current Session projection registry closure

Candidate `7720cf03`: clean-checkout release gate passed; **3235 passed, 2 skipped, 2 warnings**. Nine real registry observations match; 100 unchanged upstream projection/core Session assertions establish the source baseline. `CON-SESSION-PROJECTION@1` covers exact weak Session cells, prefix catch-up and duplicate suppression, caller-owned shared registrations, host/selected/cached reads, detached checkpoints, anchored restore and hydrate.

See [registry closure](reviews/SESSION-PROJECTION-CLOSURE-20260928.md). Next: executable domain definitions, then storageDomain and durable projection-cache, then cold Web/listing carriers. Existing keyword domain registrations and Web bridge remain compatibility adapters, not certified domain parity. Win7 remains deferred. The rebuilt package is in the managed release-repro worktree.

## Previous configured Agent closure

Candidate `5131a712`: clean-checkout release gate passed; **3219 passed, 2 skipped, 2 warnings**. Seven real configured Agent observations match alongside all prior paired gates. `CON-AGENT-CONFIG@1` covers configured identity validation/overrides, delayed resume, exact history reload, draining replacement/cancellation and contained startup failures. The Cordis child-disposer ownership fix is included and revalidated.

See [configured Agent closure](reviews/AGENT-CONFIG-CLOSURE-20260927.md). Next: full Session projection and replay contracts before Web consumers, then complete profile journeys after Wire/Tools/Web contracts. Full AgentLoop settings/tool policy and launcher integration are not certified by this bounded closure. Win7 remains deferred. The latest package is in the managed release-repro worktree.

## Previous public storage closure

Candidate `8201d7dc`: clean-checkout release gate passed; **3200 passed, 2 skipped, 2 warnings**. Eight real uncompressed JSONL storage observations match alongside prior Agent/cold/live/preparation gates. `CON-SESSION-STORAGE@1` covers shared lazy creation, batch cursor/adoption, read validation, empty live materialization and tested first-write atomic publication/rollback in both local backends.

See [public storage closure](reviews/SESSION-STORAGE-CLOSURE-20260927.md). Next: configured Agent startup/reload, then full Session projection and Web consumers. Native upstream SQLite, compressed JSONL and arbitrary cross-process/power-loss behavior are not certified. Win7 remains deferred. The latest package is in the managed release-repro worktree.

## Previous shared preparation closure

Candidate `78f35dc2`: clean-checkout release gate passed; **3175 passed, 2 skipped, 2 warnings**. Five real JSONL preparation observations match, alongside the prior Agent/cold/live gates. 197 upstream Session assertions establish a source baseline. `CON-SESSION-PREPARATIONS@1` covers the shared pool, exact reservations, cancellation, revision refresh, public write guards and teardown integration in JSONL/SQLite.

See [preparation closure](reviews/SESSION-PREPARED-CLOSURE-20260927.md). Next: public storage lazy creation, full append/read schema and cursor/adoption rules, then configured Agent startup/reload and full projection. Win7 remains deferred. The latest package is in the managed release-repro worktree.

## Previous shared live-write closure

Candidate `3de19a21`: clean-checkout release gate passed; **3142 passed, 2 skipped, 2 warnings**. Four real JSONL live lifecycle observations and seven cold-recovery observations match. The 174 upstream Session assertions establish a source baseline, not 174 Python parity cases. `CON-SESSION-LIVE-WRITES@1` covers bounded writes, failure retention/rollback, drain and tested HMR/retirement ownership in JSONL/SQLite. Shared preparation/public persistence coordination and configured Agent startup/reload remain pending.

See [live-write closure](reviews/SESSION-LIVE-CLOSURE-20260927.md). Core, Agent, Spine, Portable and cold recovery are revalidated at this candidate. Win7 remains deferred. The package is in the managed release-repro worktree, not the main checkout dist.

## Previous Session cold-recovery closure

候选 `0ab68981` 在干净检出完成发行门禁：3111 passed、2 skipped、2 warnings；七组真实 JSONL 双侧观察全部匹配，Session 原样测试 164 项通过。已验收范围为 `CON-SESSION-COLD-RECOVERY@1`，不是整个 Session 或配置重载完成。Core/Agent/Spine/Portable 在此候选重新验收；其他任务如显示 historical integration，表示本次没有重新签发其专项证据，不代表删除历史成果。

待完成实测问题与后续顺序见 [本次审阅](reviews/SESSION-COLD-CLOSURE-20260927.md) 及 `MIG-SESSION-REPLAY-002`。共享 preparation、写队列、卸载/HMR adoption 先稳定，再迁移配置恢复和 Web replay 消费者。

## 历史 Cordis 基础闭包

- 272 个 manifest 已全部分类：201 runtime、48 frontend、9 tooling、7 fixture、6 platform、1 example。分类是职责，不是模块完成计数。
- `upstream-test-inventory.json` 登记 1,227 个官方测试源文件、14,659 个字面声明，并保留参数化工厂位置；不把字面声明当成实际执行数。
- `dynamic-contract-inventory.json` 记录 1,346 个源码位置和最近 package 归属。动态表达式明确保留为待运行时解析的发现数据，不伪造完整服务图。
- `cordis-consumer-audit.json` 的 69 个必要消费者实例已有断言映射；加上生命周期 11 项，原样执行五个官方测试文件为 80 项。此前缺失的 39 项及部分断言已经补齐。
- `CON-CORDIS-CORE@10` 覆盖枚举的基础层场景和关键消费者；`CON-BOOT-SESSION-SPINE@1` 定义真实 profile → 工具 → JSONL → 关闭 → 新 Context 恢复。后者依赖前者的有效验收。
- C1–C67 是源码推导的本地场景 ID。C58 保留 Python 已完成 Future 的原生调度差异；C59 和框架侧适配场景必须匹配。原始 runner 保留失败退出码，独立 `cordis_acceptance.py` 只允许已审核的精确 C58 签名。
- Win7 真机及其浏览器验证由用户暂缓。当前 Windows / Python 3.8 验证不能替代 Win7 认证；mock LLM 不能替代真实远程模型认证。

当时产品提交 `25f59152`：全量 **3064 passed、2 skipped、2 warnings，0 failed**；关键上游原样测试 **80 passed**；双侧观察 **66 matched + C58 原生语言差异**，精确适配门禁通过。六个活动任务均已 integrated，Win7 真机验证暂缓。

最终回归、便携包和精确候选验收见 `evidence/*FINISH*`；完整审阅说明见 [本批次闭包](reviews/CORDIS-FINAL-CLOSURE-20260927.md)。历史失败日志保留用于追溯，不代表当前仍失败。旧失效发行物和启动器已退役；新便携包使用自己的 Python 3.8 运行时。

## 任务和接口规则

任务使用 `draft → ready → running → review → verified → queued → integrated`。当前工具验证记录快照，不执行自动状态机。进入 running 后必须有 owner；协调者负责处理冲突和提交集成。

`expected_paths` 是预期影响范围，**不是文件写权限白名单**。接口变更应在一个契约事务中同时修复提供端和必要消费端，增加 revision、刷新依赖和验收证据。不要在未稳定的接口上先移植下游模块；不要用互相依赖制造任务环。

`requires` 绑定提供任务、契约和 revision；提供端 integrated、契约 specified、精确提交与 revision 的有效 passing acceptance 必须同时满足，消费者才可解除阻塞。`conflicts_with` 双向生效。其他活跃作者拥有的修改应先协调，共同交付闭包不等于随意覆盖他人代码。

`contracts` 必须写清身份、所有权、顺序、错误、取消和平台适配。`mappings` 只索引测试，永远不直接认证 parity。验收记录绑定任务 acceptance 摘要、候选 commit、输入与产物哈希；陈旧输入不会满足当前门禁。

## 后续上游版本

固定观察到的上游 SHA，计算 manifest、源码、测试及动态契约变化；先审基础契约，再按提供端 → 必要消费者 → 集成 spine 排依赖。将独立模块拆成任务，接口变更合并为共享闭包。每个候选运行双侧观察、官方源断言和 Python 回归，平台适配必须有具体复现与理由。

只有已验证的明确范围可以集成。全项目 `accepted_upstream` 仍为空；本批次 Cordis/Spine 完成不等于所有业务模块或未来上游版本自动对齐。更早的阶段记录、失败复现和设计讨论保存在 reviews/evidence 与 research 文档中。
